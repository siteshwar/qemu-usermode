#ifndef _ASM_X86_KVM_PARA_H
#define _ASM_X86_KVM_PARA_H

static __inline__ unsigned int kvm_arch_para_features(void)
{
	return 0;
}

#endif /* _ASM_X86_KVM_PARA_H */
